package com.jp.couchymacro

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Outline
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.random.Random

class MainActivity : Activity() {

    private class AppItem(val label: String, val pkg: String, val image: Drawable?, val isBanner: Boolean)

    private val apps = mutableListOf<AppItem>()
    private val handler = Handler(Looper.getMainLooper())
    private var countdownRunnable: Runnable? = null
    private var bgView: ImageView? = null
    private var fetching = false
    private val badges = mutableMapOf<String, TextView>()
    private val prefs by lazy { getSharedPreferences("couchy_macro", Context.MODE_PRIVATE) }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadApps()
        val auto = apps.firstOrNull { it.pkg == prefs.getString("auto_pkg", null) }
        if (auto != null) showCountdown(auto) else showHome()
    }

    // ---------- Écran de démarrage automatique ----------
    private fun showCountdown(target: AppItem) {
        val tv = TextView(this).apply {
            text = "Ouverture de ${target.label}…\n\nAppuie sur une touche pour ouvrir le menu"
            textSize = 26f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
        }
        setContentView(tv)
        val r = Runnable {
            countdownRunnable = null
            launchPackage(target.pkg)
            finish()
        }
        countdownRunnable = r
        handler.postDelayed(r, 2000)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val r = countdownRunnable
        if (r != null) {
            handler.removeCallbacks(r)
            countdownRunnable = null
            showHome()
            return true
        }
        if (keyCode == KeyEvent.KEYCODE_MENU && bgView != null) {
            Toast.makeText(this, "Nouvelle photo…", Toast.LENGTH_SHORT).show()
            fetchPhoto(true)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onStop() {
        super.onStop()
        countdownRunnable?.let { handler.removeCallbacks(it) }
        countdownRunnable = null
    }

    // ---------- Écran d'accueil style Apple TV ----------
    private fun showHome() {
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        val root = FrameLayout(this).apply { setBackgroundColor(Color.rgb(16, 24, 32)) }

        val bg = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        bgView = bg
        root.addView(bg, FrameLayout.LayoutParams(match, match))

        val shade = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.argb(110, 0, 0, 0), Color.argb(0, 0, 0, 0), Color.argb(230, 0, 0, 0))
            )
        }
        root.addView(shade, FrameLayout.LayoutParams(match, match))

        val clock = TextClock(this).apply {
            format24Hour = "HH:mm"
            format12Hour = "HH:mm"
            textSize = 26f
            setTextColor(Color.WHITE)
            setShadowLayer(8f, 0f, 2f, Color.argb(150, 0, 0, 0))
        }
        root.addView(clock, FrameLayout.LayoutParams(wrap, wrap, Gravity.TOP or Gravity.END).apply {
            setMargins(0, dp(28), dp(48), 0)
        })

        val title = TextView(this).apply {
            textSize = 34f
            setTextColor(Color.WHITE)
            setShadowLayer(10f, 0f, 2f, Color.argb(170, 0, 0, 0))
        }
        val hint = TextView(this).apply {
            text = "OK : ouvrir   •   Maintenir OK : app de démarrage   •   Menu : nouvelle photo"
            textSize = 14f
            setTextColor(Color.argb(190, 255, 255, 255))
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            clipChildren = false
        }
        val scroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            clipChildren = false
            clipToPadding = false
            setPadding(dp(46), 0, dp(46), 0)
            addView(row)
        }
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            addView(title, LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(dp(56), 0, 0, 0) })
            addView(hint, LinearLayout.LayoutParams(wrap, wrap).apply { setMargins(dp(56), dp(2), 0, dp(6)) })
            addView(scroll, LinearLayout.LayoutParams(match, wrap))
        }
        root.addView(column, FrameLayout.LayoutParams(match, wrap, Gravity.BOTTOM).apply {
            setMargins(0, 0, 0, dp(36))
        })
        setContentView(root)

        badges.clear()
        for (item in apps) row.addView(makeTile(item, title))
        if (row.childCount > 0) row.getChildAt(0).requestFocus()

        val cached = File(filesDir, "bg.jpg")
        if (cached.exists()) BitmapFactory.decodeFile(cached.path)?.let { bg.setImageBitmap(it) }
        fetchPhoto(false)
    }

    private fun makeTile(item: AppItem, title: TextView): View {
        val radius = dp(14).toFloat()
        val frame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(210), dp(118)).apply {
                setMargins(dp(10), dp(16), dp(10), dp(34))
            }
            isFocusable = true
            isClickable = true
            background = GradientDrawable().apply {
                setColor(Color.argb(215, 42, 42, 46))
                cornerRadius = radius
            }
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, radius)
                }
            }
        }
        val img = ImageView(this).apply {
            setImageDrawable(item.image)
            if (item.isBanner) {
                scaleType = ImageView.ScaleType.CENTER_CROP
            } else {
                scaleType = ImageView.ScaleType.FIT_CENTER
                setPadding(dp(30), dp(18), dp(30), dp(18))
            }
        }
        frame.addView(img, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val border = View(this).apply {
            background = GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                setStroke(dp(3), Color.WHITE)
                cornerRadius = radius
            }
            alpha = 0f
        }
        frame.addView(border, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val badge = TextView(this).apply {
            text = "★"
            textSize = 18f
            setTextColor(Color.rgb(255, 214, 10))
            setShadowLayer(6f, 0f, 1f, Color.BLACK)
            visibility = if (prefs.getString("auto_pkg", null) == item.pkg) View.VISIBLE else View.GONE
        }
        frame.addView(badge, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.END).apply { setMargins(0, dp(4), dp(8), 0) })
        badges[item.pkg] = badge

        frame.setOnFocusChangeListener { v, has ->
            v.animate().scaleX(if (has) 1.14f else 1f).scaleY(if (has) 1.14f else 1f)
                .translationZ(if (has) dp(12).toFloat() else 0f).setDuration(140).start()
            border.animate().alpha(if (has) 1f else 0f).setDuration(140).start()
            if (has) title.text = item.label
        }
        frame.setOnClickListener { launchPackage(item.pkg) }
        frame.setOnLongClickListener {
            val current = prefs.getString("auto_pkg", null)
            if (current == item.pkg) {
                prefs.edit().remove("auto_pkg").apply()
                Toast.makeText(this, "Plus d'app de démarrage", Toast.LENGTH_SHORT).show()
            } else {
                prefs.edit().putString("auto_pkg", item.pkg).apply()
                Toast.makeText(this, "${item.label} s'ouvrira au lancement de Couchy Macro",
                    Toast.LENGTH_LONG).show()
            }
            val now = prefs.getString("auto_pkg", null)
            badges.forEach { (pkg, b) -> b.visibility = if (pkg == now) View.VISIBLE else View.GONE }
            true
        }
        return frame
    }

    // ---------- Photo d'arrière-plan (photos du jour de Bing, gratuites, sans clé) ----------
    private fun openConn(url: String): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 20000
        c.setRequestProperty("User-Agent", "Mozilla/5.0")
        return c
    }

    private fun fetchPhoto(force: Boolean) {
        val cached = File(filesDir, "bg.jpg")
        val fresh = cached.exists() && System.currentTimeMillis() - cached.lastModified() < 12 * 3600 * 1000L
        if ((!force && fresh) || fetching) return
        fetching = true
        Thread {
            try {
                val api = "https://www.bing.com/HPImageArchive.aspx?format=js&idx=0&n=8&mkt=fr-CA"
                val json = JSONObject(openConn(api).inputStream.bufferedReader().use { it.readText() })
                val arr = json.getJSONArray("images")
                val base = arr.getJSONObject(Random.nextInt(arr.length())).getString("urlbase")
                val tmp = File(filesDir, "bg_tmp.jpg")
                openConn("https://www.bing.com${base}_1920x1080.jpg").inputStream.use { i ->
                    tmp.outputStream().use { o -> i.copyTo(o) }
                }
                val bmp = BitmapFactory.decodeFile(tmp.path)
                if (bmp != null) {
                    tmp.renameTo(cached)
                    runOnUiThread {
                        if (!isFinishing) bgView?.let {
                            it.setImageBitmap(bmp)
                            it.alpha = 0f
                            it.animate().alpha(1f).setDuration(700).start()
                        }
                    }
                }
            } catch (e: Exception) {
                if (force) runOnUiThread {
                    Toast.makeText(this, "Photo indisponible (vérifie la connexion)", Toast.LENGTH_SHORT).show()
                }
            } finally {
                fetching = false
            }
        }.start()
    }

    // ---------- Apps ----------
    private fun loadApps() {
        val pm = packageManager
        val found = LinkedHashMap<String, AppItem>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val query = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(query, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName || found.containsKey(pkg)) continue
                val banner = try {
                    ri.activityInfo.loadBanner(pm) ?: ri.activityInfo.applicationInfo.loadBanner(pm)
                } catch (e: Exception) { null }
                val image = banner ?: ri.loadIcon(pm)
                found[pkg] = AppItem(ri.loadLabel(pm).toString(), pkg, image, banner != null)
            }
        }
        apps.clear()
        apps.addAll(found.values.sortedBy { it.label.lowercase() })
    }

    private fun launchPackage(pkg: String) {
        try {
            val intent = packageManager.getLeanbackLaunchIntentForPackage(pkg)
                ?: packageManager.getLaunchIntentForPackage(pkg)
            if (intent == null) {
                Toast.makeText(this, "Impossible d'ouvrir cette app", Toast.LENGTH_SHORT).show()
                return
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Erreur : ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
