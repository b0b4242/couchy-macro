package com.jp.couchymacro

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private data class AppItem(val label: String, val pkg: String)

    private val apps = mutableListOf<AppItem>()
    private val handler = Handler(Looper.getMainLooper())
    private var countdownRunnable: Runnable? = null
    private var listView: ListView? = null
    private val prefs by lazy { getSharedPreferences("couchy_macro", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadApps()
        val auto = apps.firstOrNull { it.pkg == prefs.getString("auto_pkg", null) }
        if (auto != null) showCountdown(auto) else showMenu()
    }

    // Écran de démarrage : ouvre l'app choisie après 2 s, sauf si on appuie sur une touche
    private fun showCountdown(target: AppItem) {
        val tv = TextView(this).apply {
            text = "Ouverture de ${target.label}…\n\nAppuie sur une touche pour ouvrir le menu"
            textSize = 26f
            gravity = Gravity.CENTER
        }
        setContentView(tv)
        val r = Runnable {
            countdownRunnable = null
            launchPackage(target.pkg)
            finish()
        }
        countdownRunnable = r
        handler.postDelayed(r, 2000)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        val r = countdownRunnable
        if (r != null) {
            handler.removeCallbacks(r)
            countdownRunnable = null
            showMenu()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onStop() {
        super.onStop()
        countdownRunnable?.let { handler.removeCallbacks(it) }
        countdownRunnable = null
    }

    private fun showMenu() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(64, 48, 64, 48)
        }
        val title = TextView(this).apply {
            text = "Couchy Macro"
            textSize = 30f
            setPadding(0, 0, 0, 8)
        }
        val hint = TextView(this).apply {
            text = "OK = ouvrir • Maintenir OK = app de démarrage"
            textSize = 16f
            setPadding(0, 0, 0, 24)
        }
        val lv = ListView(this).apply {
            isFocusable = true
            isFocusableInTouchMode = true
        }
        listView = lv
        root.addView(title)
        root.addView(hint)
        root.addView(lv, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        setContentView(root)

        refreshList()

        lv.setOnItemClickListener { _, _, pos, _ ->
            if (pos == 0) {
                prefs.edit().remove("auto_pkg").apply()
                Toast.makeText(this, "Plus d'app de démarrage", Toast.LENGTH_SHORT).show()
                refreshList()
            } else {
                launchPackage(apps[pos - 1].pkg)
            }
        }
        lv.setOnItemLongClickListener { _, _, pos, _ ->
            if (pos > 0) {
                val item = apps[pos - 1]
                prefs.edit().putString("auto_pkg", item.pkg).apply()
                Toast.makeText(this, "${item.label} s'ouvrira au lancement de Couchy Macro",
                    Toast.LENGTH_LONG).show()
                refreshList()
            }
            true
        }
        lv.requestFocus()
    }

    private fun refreshList() {
        val lv = listView ?: return
        val auto = apps.firstOrNull { it.pkg == prefs.getString("auto_pkg", null) }
        val rows = mutableListOf<String>()
        rows.add(if (auto != null) "★  Démarrage : ${auto.label} (OK pour retirer)"
                 else "★  Aucune app de démarrage")
        apps.forEach { rows.add(it.label) }
        lv.adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, rows) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val v = super.getView(position, convertView, parent) as TextView
                v.textSize = 22f
                v.setPadding(24, 20, 24, 20)
                return v
            }
        }
    }

    private fun loadApps() {
        val pm = packageManager
        val found = LinkedHashMap<String, AppItem>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val query = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(query, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName || found.containsKey(pkg)) continue
                found[pkg] = AppItem(ri.loadLabel(pm).toString(), pkg)
            }
        }
        apps.clear()
        apps.addAll(found.values.sortedBy { it.label.lowercase() })
    }

    private fun launchPackage(pkg: String) {
        try {
            val intent = packageManager.getLeanbackLaunchIntentForPackage(pkg)
                ?: packageManager.getLaunchIntentForPackage(pkg)
            if (intent == null) {
                Toast.makeText(this, "Impossible d'ouvrir cette app", Toast.LENGTH_SHORT).show()
                return
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Erreur : ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
